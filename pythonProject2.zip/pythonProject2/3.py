import pygame
import os


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)

    if color_key is not None:
        if color_key == -1:
            color_key = (255, 255, 255)
            image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image

class AnimatedSprite(pygame.sprite.Sprite):
    def __init__(self, sheet, columns, rows, x, y):
        super().__init__(all_sprites)
        self.frames = []
        self.cut_sheet(sheet, columns, rows)
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        self.rect = self.rect.move(x, y)

    def cut_sheet(self, sheet, columns, rows):
        self.rect = pygame.Rect(0, 0, sheet.get_width() // columns, 
                                sheet.get_height() // rows)
        for j in range(rows):
            for i in range(columns):
                frame_location = (self.rect.w * i, self.rect.h * j)
                self.frames.append(sheet.subsurface(pygame.Rect(
                    frame_location, self.rect.size)))

    def update(self):
        self.cur_frame = (self.cur_frame + 1) % len(self.frames)
        self.image = self.frames[self.cur_frame]


running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                move(hero, 'up')
            elif event.key == pygame.K_DOWN:
                move(hero, 'down')
            if event.key == pygame.K_LEFT:
                move(hero, 'left')
            if event.key == pygame.K_RIGHT:
                move(hero, 'right')
                dragon = AnimatedSprite(load_image("move_down.jpg"), 4, 1, 50, 50)
    screen.fill(pygame.Color('black'))

    tiles_group.draw(screen)
    player_group.draw(screen)


    pygame.display.flip()
    clock.tick(50)
pygame.quit()
dragon = AnimatedSprite(load_image("dragon_sheet8x2.png"), 8, 2, 50, 50)
